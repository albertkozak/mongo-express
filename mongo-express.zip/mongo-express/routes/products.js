var express = require("express");
var router = express.Router();
var mongojs = require("mongojs");
var config = require("../config");

var db = mongojs(config.database_connection, [config.database]);

router.get("/products", (req, res, next) => {
  db.products.find((err, data) => {
    if (err) res.send(err);

    res.json(data);
  });
});

// Get Single Product
router.get("/products/:id", (req, res, next) => {
  db.products.findOne({ _id: mongojs.ObjectId(req.params.id) }, function(
    err,
    data
  ) {
    if (err) {
      res.send(err);
    }
    res.json(data);
  });
});

// Create Product
router.post("/products", (req, res, next) => {
  var product = req.body;
  if (!product.product || !product.category || !product.price) {
    res.status(400);
    res.json({ error: "Bad data, could not insert in database" });
  } else {
    db.products.save(product, (err, data) => {
      if (err) {
        res.send(err);
      }
      res.status(200);
      res.json(data);
    });
  }
});
// Delete Product
router.delete("/products/:id", (req, res, next) => {
  db.products.remove({ _id: mongojs.ObjectId(req.params.id) }, function(
    err,
    data
  ) {
    if (err) {
      res.status(400);
      res.send(err);
    }
    res.json(data);
  });
});

// Update Product
router.put("/products/:id", (req, res, next) => {
  const product = req.body;
  const changedproduct = {};

  if (product.product) {
    changedproduct.product = product.product;
  }

  if (product.category) {
    changedproduct.category = product.category;
  }

  if (product.price) {
    changedproduct.price = product.price;
  }

  if (Object.keys(changedproduct).length == 0) {
    res.status(400);
    res.json({ error: "Bad Data" });
  } else {
    console.log(changedproduct);
    db.products.update(
      { _id: mongojs.ObjectId(req.params.id) },
      { $set: changedproduct },
      {},
      function(err, data) {
        if (err) {
          res.status(400);
          res.send(err);
        }
        res.json(data);
      }
    );
  }
});

module.exports = router;
