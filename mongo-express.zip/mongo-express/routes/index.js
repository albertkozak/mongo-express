var express = require("express");
var router = express.Router();
const config = require("../config");
const mongojs = require("mongojs");
const db = mongojs(config.database_connection, [config.database]);

router.get("/", (req, res, next) => {
  db.products.find(function(err, docs) {
    res.render("index", {
      title: "MONGO EXPRESS",
      products: docs
    });
  });
});

module.exports = router;
