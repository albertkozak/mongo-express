var express = require("express");
var router = express.Router();
var mongojs = require("mongojs");
var config = require("../config");

var db = mongojs(config.database_connection, [config.database]);

router.get("/students", (req, res, next) => {
  db.students.find((err, data) => {
    if (err) res.send(err);

    res.json(data);
  });
});

router.get("/students/:id", (req, res, next) => {
  db.students.findOne({ _id: mongojs.ObjectId(req.params.id) }, function(
    err,
    data
  ) {
    if (err) {
      res.send(err);
    }
    res.json(data);
  });
});

router.post("/students", (req, res, next) => {
  var student = req.body;

  if (!student.StartDate) {
    student.StartDate = new Date();
  }

  if (!student.FirstName || !student.LastName || !student.School) {
    res.status(400);
    res.json({ error: "Bad data, could not be inserted into the database." });
  } else {
    db.students.save(student, function(err, data) {
      if (err) {
        res.send(err);
      }
      res.json(data);
    });
  }
});

router.delete("/students/:id", (req, res, next) => {
  db.students.remove({ _id: mongojs.ObjectId(req.params.id) }, function(
    err,
    data
  ) {
    if (err) {
      res.status(400);
      res.send(err);
    }
    res.json(data);
  });
});

router.put("/students/:id", (req, res, next) => {
  var student = req.body;
  var changedStudent = {};

  if (student.FirstName) {
    changedStudent.FirstName = student.FirstName;
  }

  if (student.LastName) {
    changedStudent.LastName = student.LastName;
  }

  if (student.School) {
    changedStudent.School = student.School;
  }

  if (student.StartDate) {
    changedStudent.StartDate = student.StartDate;
  }

  if (Object.keys(changedStudent).length == 0) {
    res.status(400);
    res.json({ error: "Bad Data" });
  } else {
    console.log(changedStudent);
    db.students.update(
      { _id: mongojs.ObjectId(req.params.id) },
      { $set: changedStudent },
      {},
      function(err, data) {
        if (err) {
          res.status(400);
          res.send(err);
        }
        res.json(data);
      }
    );
  }
});

module.exports = router;
