module.exports = {
  database_connection: "", // ADD YOUR MONGODB CONNECTION STRING HERE
  database_ignore: "school",
  database: "products",
  port: process.env.PORT || 3000
};
